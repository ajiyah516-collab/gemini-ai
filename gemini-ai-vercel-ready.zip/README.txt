GEMINI AI - VERCEL

Cara deploy dari HP:
1. Buat akun/login Vercel.
2. Buat project GitHub baru dan upload isi folder project ini.
3. Di Vercel pilih "Add New Project" lalu pilih repository tersebut.
4. Deploy.
5. Buka Project Settings > Environment Variables.
6. Tambahkan:
   Name: GEMINI_API_KEY
   Value: API KEY GEMINI ANDA
   Environment: Production
7. Redeploy project.
8. Buka URL Vercel Anda.

PENTING:
- Jangan masukkan API key ke index.html.
- Jangan upload API key ke GitHub.
- API key disimpan di Vercel Environment Variables.

STRUKTUR:
public/index.html = tampilan web
api/chat.js = serverless API Gemini
vercel.json = konfigurasi Vercel
